# Validation — E2EE v5

PASS: npm test (tests/e2ee.test.js). Direct and 3-member groups; AES-GCM and DES-CBC/HMAC; text + image; decrypt by sender and members; outsider, wrong private key, substituted sender public key, modified ciphertext and modified wrapped key rejected by endpoints. Server rejects archiveKey/plaintext, legacy write API disabled. MongoDB-shaped repository, API responses, SSE and history contain ciphertext only for new messages. Existing plaintext record is not returned. Restart/login/password-vault unlock recovers encrypted history. Idempotency and membership checks pass.

Tests use an in-memory repository. Live MongoDB Atlas not exercised. Browser test updated; not executed successfully because Chromium executable is absent. No visual QA or production-security certification claimed. Threat model and limitations in README.md.
