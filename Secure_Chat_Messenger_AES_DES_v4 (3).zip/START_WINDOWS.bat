@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Can cai Node.js 24 tro len.
 pause
 exit /b 1
)
node -e "process.exit(Number(process.versions.node.split('.')[0])>=24?0:1)"
if errorlevel 1 (
 echo Can Node.js 24 tro len.
 pause
 exit /b 1
)
if not exist "node_modules\mongodb\package.json" (
 call npm.cmd install
 if errorlevel 1 (
  pause
  exit /b 1
 )
)
node --env-file-if-exists=.env Backend/server.js
pause
