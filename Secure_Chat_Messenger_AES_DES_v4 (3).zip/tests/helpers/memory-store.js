// Test double only. The application launcher ALWAYS uses MongoDB.
const stores=new Map();
export function memoryStore(name){
 if(!stores.has(name))stores.set(name,{users:[],messages:[],groups:[],seq:0});const data=stores.get(name);
 const matches=(row,filter)=>Object.entries(filter).every(([k,v])=>row[k]===v);
 const copy=x=>x?structuredClone(x):null;
 const duplicate=()=>Object.assign(Error('duplicate'),{code:11000});
 const repo={
 listGroups:async id=>data.groups.filter(g=>g.members.includes(id)).map(copy),
 findGroup:async id=>copy(data.groups.find(g=>g.id===id)),
 addGroup:async row=>{data.groups.push(copy(row));},
 chatHistory:async(conversation,before)=>data.messages.filter(x=>x.conversation===conversation&&x.seq<before).sort((a,b)=>b.seq-a.seq).slice(0,51).map(copy),
 findUser:async f=>copy(data.users.find(x=>matches(x,f))),
 addUser:async row=>{if(data.users.some(x=>x.username===row.username||x.id===row.id))throw duplicate();data.users.push(copy(row));},
 listUsers:async id=>data.users.filter(x=>x.id!==id).sort((a,b)=>a.username.localeCompare(b.username)).map(copy),
 findMessage:async id=>copy(data.messages.find(x=>x.id===id)),
 history:async(me,peer,before)=>data.messages.filter(x=>x.seq<before&&((x.sender===me&&x.recipient===peer)||(x.sender===peer&&x.recipient===me))).sort((a,b)=>b.seq-a.seq).slice(0,51).map(copy),
 addMessage:async row=>{if(data.messages.some(x=>x.id===row.id))throw duplicate();const record={...copy(row),seq:++data.seq};data.messages.push(record);return copy(record);},
 close:async()=>{},
 db:{dropDatabase:async()=>{data.users=[];data.messages=[];data.seq=0;stores.delete(name);}},
 messages:{findOne:async f=>copy(data.messages.find(x=>matches(x,f)))}
 };return repo;
}
