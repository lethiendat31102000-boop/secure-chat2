import test from 'node:test';import assert from 'node:assert/strict';import {randomUUID} from 'node:crypto';
import {createApp} from '../Backend/app.js';import {memoryStore} from './helpers/memory-store.js';
import {makeIdentity,unlockIdentity,authProof} from '../Frontend/js/crypto/messaging.js';
import {encryptE2EE,decryptE2EE} from '../Frontend/js/crypto/e2ee.js';
test('E2EE direct/group: ciphertext-only storage and wire, offline history, restart, tampering, access control',async()=>{
 const store=memoryStore('e2ee-'+randomUUID());let app=await createApp({repository:store});await new Promise(r=>app.server.listen(0,'127.0.0.1',r));let reader;
 const base=()=>`http://127.0.0.1:${app.server.address().port}/api`;
 async function req(path,data,user){const r=await fetch(base()+path,{method:data===undefined?'GET':'POST',headers:{cookie:user?.cookie||'',...(data===undefined?{}:{'Content-Type':'application/json','X-Requested-With':'SecureChat'})},body:data===undefined?undefined:JSON.stringify(data)});return {status:r.status,body:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]};}
 async function register(username){const identity=await makeIdentity(username,'test-pass-123');const r=await req('/register',{username,...identity});assert.equal(r.status,201);return {...r.body,cookie:r.cookie,privateKey:await unlockIdentity(username,'test-pass-123',identity.vault,identity.publicJwk)};}
 async function decrypt(packet,user,sender){return decryptE2EE(packet,{userId:user.id,privateKey:user.privateKey,senderPublicJwk:sender.publicJwk});}
 function noPlain(row){for(const k of ['text','image','decryptedText','archiveKey','privateKey'])assert.equal(row[k],undefined);}
 try{
 const a=await register('alice'),b=await register('bob'),c=await register('carol'),d=await register('outside');
 const group=await req('/groups',{name:'Study',members:[b.id,c.id]},a);assert.equal(group.status,201);const groupTarget='group:'+group.body.id;
 const stream=await fetch(base()+'/events',{headers:{cookie:b.cookie}});reader=stream.body.getReader();await reader.read();
 let savedPacket;
 for(const algorithm of ['AES-GCM','DES-CBC'])for(const isGroup of [false,true]){
 const text='Tin bí mật 🔐 '+algorithm+' '+isGroup,image='data:image/png;base64,aGVsbG8=';
 const wire=await encryptE2EE({text,image,algorithm,from:a.id,target:isGroup?groupTarget:b.id,privateKey:a.privateKey,accounts:isGroup?[a,b,c]:[a,b]});
 noPlain(wire);assert.ok(!JSON.stringify(wire).includes(text));const sent=await req('/chat/send',wire,a);assert.equal(sent.status,201);noPlain(sent.body);
 const stored=await store.findMessage(wire.packet.envelope.id);noPlain(stored);assert.ok(!JSON.stringify(stored).includes(text));assert.deepEqual(stored.packet,wire.packet);
 for(const u of isGroup?[a,b,c]:[a,b])assert.deepEqual(await decrypt(sent.body.packet,u,a),{text,image});
 await assert.rejects(decrypt(sent.body.packet,d,a));
 const bad=structuredClone(wire.packet);bad.envelope.ciphertext=(bad.envelope.ciphertext[0]==='A'?'B':'A')+bad.envelope.ciphertext.slice(1);await assert.rejects(decrypt(bad,b,a));
 const wrong=structuredClone(wire.packet);wrong.wrappedKeys[b.id].ciphertext='00'.repeat(algorithm==='AES-GCM'?48:56);await assert.rejects(decrypt(wrong,b,a));
 await assert.rejects(decryptE2EE(wire.packet,{userId:b.id,privateKey:d.privateKey,senderPublicJwk:a.publicJwk}));
 await assert.rejects(decryptE2EE(wire.packet,{userId:b.id,privateKey:b.privateKey,senderPublicJwk:d.publicJwk}));
 assert.equal((await req('/chat/send',wire,a)).status,200);
 assert.equal((await req('/chat/send',{...wire,archiveKey:'must-not-be-accepted'},a)).status,400);
 assert.equal((await req('/chat/send',{...wire,text},a)).status,400);
 assert.equal((await req('/chat/send',wire,d)).status,403);
 let events='';while(!events.includes(wire.packet.envelope.id))events+=new TextDecoder().decode((await reader.read()).value);assert.ok(events.includes('event: chat'));assert.ok(!events.includes(text));assert.ok(!events.includes('archiveKey'));
 savedPacket=wire.packet;
 }
 const history=await req('/chat/history?target='+groupTarget,undefined,c);assert.equal(history.body.messages.length,2);for(const row of history.body.messages){noPlain(row);assert.ok((await decrypt(row.packet,c,a)).text.startsWith('Tin bí mật'));}
 assert.equal((await req('/chat/history?target='+groupTarget,undefined,d)).status,403);
 assert.equal((await req('/chat/history?target='+a.id,undefined,d)).body.messages.length,0);
 assert.equal((await req('/messages',{envelope:savedPacket.envelope,archiveKey:'bad'},a)).status,410);
 assert.equal((await req('/chat/send',{target:b.id,id:randomUUID(),text:'plain'},a)).status,400);
 await store.addMessage({id:randomUUID(),conversation:[a.id,b.id].sort().join(':'),sender:a.id,recipient:b.id,decryptedText:'old plaintext',image:'old image',receivedAt:Date.now()});
 const legacy=await req('/chat/history?target='+a.id,undefined,b);assert.ok(!JSON.stringify(legacy.body).includes('old plaintext'));assert.ok(legacy.body.messages.some(x=>x.legacy));
 await reader.cancel();reader=null;await app.close();app=await createApp({repository:store});await new Promise(r=>app.server.listen(0,'127.0.0.1',r));
 const config=await req('/auth/config?username=bob');const login=await req('/login',{username:'bob',proof:await authProof('test-pass-123',config.body.authSalt)});assert.equal(login.status,200);
 const unlocked=await unlockIdentity('bob','test-pass-123',login.body.vault,login.body.publicJwk);await assert.rejects(unlockIdentity('bob','wrong-password',login.body.vault,login.body.publicJwk));
 const after=await req('/chat/history?target='+groupTarget,undefined,{cookie:login.cookie});assert.equal(after.body.messages.length,2);
 assert.ok((await decryptE2EE(after.body.messages[0].packet,{userId:b.id,privateKey:unlocked,senderPublicJwk:a.publicJwk})).text.startsWith('Tin bí mật'));
 }finally{await reader?.cancel();await app.close();}
});
